package com.hasson.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8, 8, 10);
    private final int RED = Color.rgb(235, 20, 35);
    private final int WHITE = Color.rgb(245, 245, 248);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 26, 22, 24);
        root.setBackgroundColor(BG);
        scroll.addView(root);
        setContentView(scroll);

        root.addView(label("♛", 48, RED, true));
        TextView name = label("HASSON", 38, WHITE, true);
        name.setLetterSpacing(0.08f);
        root.addView(name);
        root.addView(label("LAUNCHER", 25, RED, true));
        TextView edition = label("MINECRAFT JAVA EDITION", 13, WHITE, true);
        edition.setPadding(0, 4, 0, 22);
        root.addView(edition);

        TextView hero = label("MINECRAFT\nJAVA LAUNCHER", 24, WHITE, true);
        hero.setBackground(panel());
        hero.setPadding(10, 22, 10, 22);
        root.addView(hero);

        TextView version = label("VERSION\n1.21.1", 22, WHITE, true);
        version.setBackground(panel());
        version.setPadding(8, 12, 8, 12);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.setMargins(0, 18, 0, 8);
        root.addView(version, vp);

        Button play = makeButton("▶   PLAY");
        play.setTextSize(24);
        play.setBackground(panelRed());
        play.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Hasson Launcher")
            .setMessage("This is the first interface prototype. The Minecraft Java runtime, game downloads, Microsoft authentication and real Play function are not integrated yet.")
            .setPositiveButton("OK", null).show());
        root.addView(play);

        Button login = makeButton("Microsoft Account  ›");
        login.setOnClickListener(v -> toast("Microsoft sign-in will be added in a later development stage."));
        root.addView(login);

        Button ram = makeButton("RAM: Auto (device-friendly)");
        ram.setOnClickListener(v -> toast("RAM tuning will be added after the Java runtime is integrated."));
        root.addView(ram);

        Button preset = makeButton("✓  LOW-END PRESET");
        preset.setOnClickListener(v -> toast("Low-end preset selected (interface preview)."));
        root.addView(preset);

        Button telegram = makeButton("TELEGRAM  @Flashgamer1");
        telegram.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW,
            Uri.parse("https://t.me/Flashgamer1"))));
        root.addView(telegram);

        TextView foot = label("Prototype 0.1 • Minecraft engine not integrated", 11, Color.LTGRAY, false);
        foot.setPadding(0, 18, 0, 0);
        root.addView(foot);
    }

    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable panel() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.rgb(19, 13, 16)); d.setCornerRadius(24); d.setStroke(2, RED);
        return d;
    }

    private GradientDrawable panelRed() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(RED); d.setCornerRadius(24); d.setStroke(2, RED);
        return d;
    }

    private Button makeButton(String title) {
        Button b = new Button(this);
        b.setText(title); b.setTextColor(WHITE); b.setAllCaps(false); b.setTextSize(16);
        b.setBackground(panel());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 58);
        p.setMargins(0, 8, 0, 8); b.setLayoutParams(p);
        return b;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
