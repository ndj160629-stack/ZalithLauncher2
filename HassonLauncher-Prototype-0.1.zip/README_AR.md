# Hasson Launcher — Prototype 0.1

هذا مشروع أندرويد أولي بواجهة سوداء وحمراء باسم Hasson Launcher، مع زر قناة Telegram.

**تنبيه مهم:** هذه نسخة واجهة أولية قابلة للبناء إلى APK، وليست لانشر Minecraft Java كاملاً بعد. زر Play يوضح أن محرك Java غير مدمج. لا يوجد حالياً تسجيل دخول Microsoft أو تنزيل إصدارات أو تشغيل اللعبة.

## البناء من GitHub
ارفع محتويات هذا المجلد إلى مستودع GitHub جديد على فرع `main`. افتح تبويب Actions وشغّل `Build Hasson Launcher APK`. بعد نجاح البناء، افتح نتيجة التشغيل ونزّل Artifact باسم `HassonLauncher-debug-apk`.

المتطلبات في بيئة البناء: JDK 17، Gradle 8.9، Android Gradle Plugin 8.7.3، Android SDK 35.

## مراحل تحويله إلى لانشر حقيقي
يجب إضافة Android Java runtime، تنزيل ملفات Minecraft وأصولها، تسجيل الدخول الرسمي، استخراج native libraries، ثم تشغيل اللعبة عبر طبقة عرض متوافقة. هذه الأجزاء غير موجودة في النسخة الأولية.
